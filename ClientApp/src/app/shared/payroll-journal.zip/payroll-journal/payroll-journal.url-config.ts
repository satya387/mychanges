import { environment } from 'src/environments/environment';

const BASE_URL = environment.apiBaseUrl;

export const PAYROLL_JOURNAL_URLS = {
  UPLOAD_PAYROLL_JOURNAL: BASE_URL + 'PayrollJournal/Upload',
}
