import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { PayrollJournalService } from './payroll-journal.service';
import { ToastService } from 'src/app/common/toast/toast.service';

// import {MatIconModule} from '@angular/material/icon';
// import { MatDatepickerModule } from '@angular/material/datepicker';
// import { MatInputModule } from '@angular/material/input';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatNativeDateModule } from '@angular/material/core';

@Component({
  selector: 'app-request-resource',
  templateUrl: './payroll-journal.component.html',
})
export class PayrollJournalComponent {

  title = 'read-excel-in-angular8';
  storeData: any;
  csvData: any;
  jsonData: any;
  inputData: any;
  textData: any;
  htmlData: any;
  fileUploaded: File;
  worksheet: any;
  responseMessage: string;
  constructor(private toastService: ToastService, private payrollJournalService: PayrollJournalService, private router: Router) {

  }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    debugger;
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      this.worksheet = ws;
    };
    reader.readAsArrayBuffer(this.fileUploaded);
  }
  readAsJson() {
    debugger;
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });
    if (this.jsonData.length > 0) {
      this.inputData = JSON.stringify(this.jsonData);
      const data: Blob = new Blob([this.jsonData], { type: "application/json" });
      this.uploadPayrollJournal();
    }
    else {
      this.toastService.showError('Please choose a file to upload', 'Error');
      return;
    }
    //FileSaver.saveAs(data, "JsonFile" + new Date().getTime() + '.json');
  }

  generateRequestBody(inputJsonData) {
    const object = { 
      inputJsonData
    }
    return object;
  }

  uploadPayrollJournal() {
    debugger;
    const requestBody = this.generateRequestBody(this.inputData);
    this.payrollJournalService.uploadPayrollJournal(requestBody).subscribe((response: any) => {
      console.log("respone - ", response);
      console.log("responeData - ", response.data);
      debugger;
      if (response && !response.isError) {
        this.toastService.showSuccess(response.message, 'Success');
        this.worksheet = "";
        let element: HTMLElement = document.getElementById('btnReset') as HTMLElement;
        element.click();
        this.router.navigate(['/payroll-journal']);
      } else {
        this.toastService.showError(response.message, 'Error');
        return;
      }
    })
  }

}
