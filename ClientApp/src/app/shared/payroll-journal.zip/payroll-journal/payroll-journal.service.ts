import { Injectable } from '@angular/core';

import { HttpClient, HttpParams } from '@angular/common/http';
import { PAYROLL_JOURNAL_URLS } from './payroll-journal.url-config';

@Injectable({
  providedIn: 'root'
})
export class PayrollJournalService {
  viewAllTileDetail: any;

  constructor(private http: HttpClient) { }

  uploadPayrollJournal(requestBody) {
    debugger;
    console.log('requestBody - ', requestBody);
    //var formData = new FormData();
    //formData.append('jsonData', requestBody);
    //console.log('formdata - ', formData);

    //var inputData = JSON.stringify(requestBody);
    //console.log('inputData - ', inputData);
    //return this.http.post(PAYROLL_JOURNAL_URLS.UPLOAD_PAYROLL_JOURNAL, requestBody);
    var a = this.http.post(PAYROLL_JOURNAL_URLS.UPLOAD_PAYROLL_JOURNAL, requestBody);
    debugger;
    return a;
  }
}
